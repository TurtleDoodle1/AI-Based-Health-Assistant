/**
 * 
 */
/**
 * 
 */
module YapayZekaDestekliSağlıkAsistanı {
	requires java.desktop;
	requires java.sql;
	requires org.json;
}