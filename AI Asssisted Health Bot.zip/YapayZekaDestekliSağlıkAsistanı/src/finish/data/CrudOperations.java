package finish.data;

import finish.model.Disease;
import java.sql.*; 
import java.util.*;

public class CrudOperations {

    public void create(Disease disease) throws SQLException {
        String insertSQL = "INSERT INTO diseases (name, symptoms, treatment) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            pstmt.setString(1, disease.getName());
            pstmt.setString(2, disease.getSymptomsAsString());
            pstmt.setString(3, disease.getTreatment());
            pstmt.executeUpdate();
        }
    }

    public Disease readById(int id) throws SQLException {
        String query = "SELECT id, name, symptoms, treatment FROM diseases WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Disease(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("symptoms"),
                        rs.getString("treatment")
                    );
                }
            }
        }
        return null;
    }

    public List<Disease> readAll() throws SQLException {
        String query = "SELECT id, name, symptoms, treatment FROM diseases";
        List<Disease> diseaseList = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
        		ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Disease disease = new Disease(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("symptoms"),
                    rs.getString("treatment")
                );
                diseaseList.add(disease);
            }
        }
        return diseaseList;
    }

    public void update(Disease disease) throws SQLException {
        String sql = "UPDATE diseases SET name = ?, symptoms = ?, treatment = ? WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, disease.getName());
            pstmt.setString(2, disease.getSymptomsAsString());
            pstmt.setString(3, disease.getTreatment());
            pstmt.setInt(4, disease.getId());
            pstmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM diseases WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
