package finish.data;

import java.sql.*; 

public class DatabaseManager {
    private static Connection connection = null;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection("jdbc:sqlite:medical.db");
            initializeDatabase();
        }
        return connection;
    }

    private static void initializeDatabase() throws SQLException {
        String createTableSQL = """
            CREATE TABLE IF NOT EXISTS diseases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                symptoms TEXT,
                treatment TEXT
            );
            """;

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(createTableSQL);}
        }
    
}