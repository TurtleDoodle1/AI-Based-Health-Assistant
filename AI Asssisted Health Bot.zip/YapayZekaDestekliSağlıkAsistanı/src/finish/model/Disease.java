package finish.model;

import java.util.*;
import java.util.stream.*;

public class Disease {
	
	    private int id;
	    private String name;
	    private Set<String> symptoms;
	    private String treatment;
	    
	    public Disease(int id, String name, String symptoms, String treatment) {
	        this.id = id;
	        this.name = name;
	        this.symptoms = new HashSet<>(Arrays.asList(symptoms.toLowerCase(Locale.ROOT).split("[,\\s]+")));
	        this.treatment = treatment;
	    }
	
	    public Disease(String name, String symptoms, String treatment) {
	        this(0, name, symptoms, treatment);

	    }
	    
	    public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }

	    public Set<String> getSymptoms() {
	        return symptoms;
	    }

	    // symptoms Set'ini virgülle ayrılmış bir String olarak döndürür
	    public String getSymptomsAsString() {
	        return symptoms.stream().collect(Collectors.joining(", "));
	    }
	    
	    public String getTreatment() {
	        return treatment;
	    }
	    
	    public void setId(int id) {
	        this.id = id;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public void setSymptoms(String symptoms) {
	        this.symptoms = new HashSet<>(Arrays.asList(symptoms.toLowerCase(Locale.ROOT).split("[,\\s]+")));
	    }

	    public void setTreatment(String treatment) {
	        this.treatment = treatment;
	    }
	    
	    @Override
	    public String toString() {
	        return "Disease{" +
	               "id=" + id +
	               ", name='" + name + '\'' +
	               ", symptoms=" + symptoms +
	               ", treatment='" + treatment + '\'' +
	               '}';
	    }

}
