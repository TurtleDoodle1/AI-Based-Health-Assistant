package finish.model;

public class UserData {
	
	private String gender;
    private int age;
    private String symptoms;

    public UserData(String gender, int age, String symptoms) {
        this.gender = gender;
        this.age = age;
        this.symptoms = symptoms;
    }
    
    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getSymptoms() {
        return symptoms;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    @Override
    public String toString() {
        return "UserData{" +
               "gender='" + gender + '\'' +
               ", age=" + age +
               ", symptoms='" + symptoms + '\'' +
               '}';
    }
}
