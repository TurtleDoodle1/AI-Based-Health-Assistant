package finish.service;
import java.io.*;
import java.net.*;
import org.json.JSONArray;
import org.json.JSONObject;


public class OllamaService {
    private static final String OLLAMA_API_URL = "http://localhost:11434/api/chat";
    private static final String OLLAMA_MODEL = "gemma3";

    public String sendMessage(String message) {
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(OLLAMA_API_URL).openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);

            JSONObject requestJson = new JSONObject()
                .put("model", OLLAMA_MODEL)
                .put("messages", new JSONArray().put(new JSONObject()
                    .put("role", "user")
                    .put("content", message)))
                .put("stream", false);

            try (OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream())) {
                writer.write(requestJson.toString());
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            JSONObject json = new JSONObject(response.toString());
            return json.getJSONObject("message").getString("content");

        } catch (Exception e) {
            System.err.println("Ollama API Error: " + e.getMessage());
            e.printStackTrace();
            return "Ollama Error: " + e.toString();
        }
    }
}