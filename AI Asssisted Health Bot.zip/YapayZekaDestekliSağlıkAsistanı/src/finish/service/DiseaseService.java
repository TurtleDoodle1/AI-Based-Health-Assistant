package finish.service;

import finish.data.CrudOperations;
import finish.model.Disease;
import java.sql.SQLException;
import java.util.*;

public class DiseaseService {
    private CrudOperations crudOperations;
    private List<Disease> cachedDiseases;

    public DiseaseService() {
        this.crudOperations = new CrudOperations();
        this.cachedDiseases = new ArrayList<>();
        loadDiseasesFromDatabase();
    }

    private void loadDiseasesFromDatabase() {
        try {
            this.cachedDiseases = crudOperations.readAll();
            System.out.println("Loaded diseases (from service):");

            this.cachedDiseases.forEach(d -> System.out.println("Name: " + d.getName() + " | Symptoms: " + d.getSymptomsAsString() + " | Treatments: " + d.getTreatment()));
        } catch (SQLException e) {
            System.err.println("Error loading diseases from database: " + e.getMessage());
            e.printStackTrace();
            this.cachedDiseases = new ArrayList<>();
        }
    }

    public List<Disease> predictDisease(String input) {
        input = input.toLowerCase(Locale.ROOT).trim();
        Set<String> inputSymptoms = new HashSet<>(Arrays.asList(input.split("[,\\s]+")));

        if (inputSymptoms.isEmpty()) {
            return new ArrayList<>();
        }

        Disease bestMatch = null;
        double maxLogProbability = Double.NEGATIVE_INFINITY;

        Set<String> allUniqueSymptoms = new HashSet<>();
        for (Disease disease : cachedDiseases) {
            allUniqueSymptoms.addAll(disease.getSymptoms());
        }
        int vocabularySize = allUniqueSymptoms.size();

        for (Disease disease : cachedDiseases) {
            double logPrior = Math.log(1.0 / cachedDiseases.size());
            double logLikelihood = 0.0;
            int totalSymptomsForDisease = disease.getSymptoms().size();

            for (String inputSymptom : inputSymptoms) {
                boolean foundExactOrPartialMatch = false;
                for (String diseaseSymptom : disease.getSymptoms()) {
                    if (diseaseSymptom.contains(inputSymptom) || inputSymptom.contains(diseaseSymptom)) {
                        foundExactOrPartialMatch = true;
                        break;
                    }
                }

                if (foundExactOrPartialMatch) {
                    logLikelihood += Math.log((1.0 + 1.0) / (totalSymptomsForDisease + vocabularySize));
                } else {
                    logLikelihood += Math.log((0.0 + 1.0) / (totalSymptomsForDisease + vocabularySize));
                }
            }

            double currentLogProbability = logLikelihood + logPrior;

            if (currentLogProbability > maxLogProbability) {
                maxLogProbability = currentLogProbability;
                bestMatch = disease;
            }
        }

        if (bestMatch != null) {
            return List.of(bestMatch);
        } else {
            return new ArrayList<>();
        }
    }}
