package finish.app;

import finish.model.*;
import finish.service.*;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.*;

public class GUI {

    JFrame frame, mainPageFrame, gripFrame, chatFrame, introductionFrame, infoFrame, acquaintFrame, collectorFrame, reportFrame;
    JPanel logPage, mainPage, gripPage, chatPage, introductionPage, infoPage, acquaintPage, collectorPage, reportPage;
    JLabel userLabel, passwordLabel, resultLabel, gripLabel, chatLabel, introductionLabel, genderLabel, ageLabel, symptomsLabel, reportLabel, genderReportLabel, ageReportLabel, symptomsReportLabel, sypmtomsLabel, sicknessLabel, adviceLabel, genderDisplayLabel;

    JSlider genderSlider;
    JTextField login1, search, chat, ageField, symptomsField;
    JButton button, searchButton, chatButton, chatWork, generalButton, introButton, proceedMain, collectorButton, reportButton, closeButton, backButton, reportButtonGripPage, backInfoButton, backAcquaintButton;
    JTextArea chatDisplay, infoDisplay;
    JPasswordField login2;

    
    private DiseaseService diseaseService;
    private OllamaService ollamaService;

    
    private UserData userData;
    private Disease lastPredictedDisease;
    private String selectedGender;

    public GUI() {
        this.diseaseService = new DiseaseService();
        this.ollamaService = new OllamaService();

        frame = new JFrame();
        mainPageFrame = new JFrame();
        gripFrame = new JFrame();
        chatFrame = new JFrame();
        introductionFrame = new JFrame();
        infoFrame = new JFrame();
        acquaintFrame = new JFrame();
        collectorFrame = new JFrame();
        reportFrame = new JFrame();

        
        genderSlider = new JSlider(JSlider.HORIZONTAL, 0, 1, 0);

        
        logPage = new JPanel();
        mainPage = new JPanel();
        chatPage = new JPanel();
        gripPage = new JPanel();
        introductionPage = new JPanel();
        infoPage = new JPanel();
        acquaintPage = new JPanel();
        collectorPage = new JPanel();
        reportPage = new JPanel();

        
        userLabel = new JLabel();
        gripLabel = new JLabel("Ben gribim");
        chatLabel = new JLabel();
        passwordLabel = new JLabel();
        resultLabel = new JLabel("Tahmin sonucu burada görünecek");
        introductionLabel = new JLabel("Birini seçiniz");
        genderLabel = new JLabel("Cinsiyet");
        ageLabel = new JLabel("Yas");
        symptomsLabel = new JLabel("Açıklama");
        reportLabel = new JLabel("Raport");
        sypmtomsLabel = new JLabel("Belirtiler");
        sicknessLabel = new JLabel("Hastalık");
        adviceLabel = new JLabel("Tavsiye");
        genderDisplayLabel = new JLabel("Erkek");


        login1 = new JTextField();
        login2 = new JPasswordField();
        search = new JTextField();
        chat = new JTextField();
        ageField = new JTextField();
        symptomsField = new JTextField();

        chatDisplay = new JTextArea();
        infoDisplay = new JTextArea();

        // ---------------------------------------------------- GENERAL USE BUTTON(s)
        closeButton = new JButton("Bitir");
        closeButton.setBounds(390, 360, 80, 80);
        closeButton.setFont(new Font("MV Boli", Font.PLAIN, 20));
        closeButton.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(closeButton);
            if (window != null) {
                window.dispose();
            }
        });

        reportButton = new JButton("Rapora geç");
        reportButton.setBounds(580, 620, 180, 100);
        reportButton.setFont(new Font("Arial", Font.BOLD, 23));
        reportButton.setVisible(false);
        reportButton.setFocusable(false);
        reportButton.addActionListener(e -> changeFrame(mainPageFrame, reportFrame));


        // ------------------------------------ LOG-IN PAGE

        button = new JButton("Log in");
        button.setFont(new Font("MV Boli", Font.PLAIN, 20));
        button.setBounds(160, 225, 100, 100);
        button.setSize(new Dimension(150, 100));
        button.setFocusable(false);
        button.addActionListener(e -> loggingIn());

        login1.setBounds(200, 115, 200, 30);
        login2.setBounds(200, 160, 200, 30);

        userLabel.setText("Username");
        userLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));
        userLabel.setBounds(30, 75, 200, 100);

        passwordLabel.setText("Password");
        passwordLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));
        passwordLabel.setBounds(30, 125, 200, 100);

        frame.add(logPage, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setTitle("Yapay Zekâ Destekli Sağlık Asistanı");
        frame.setResizable(false);
        frame.setVisible(true);

        logPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        logPage.setLayout(null);
        logPage.add(button);
        logPage.add(userLabel);
        logPage.add(passwordLabel);
        logPage.add(login1);
        logPage.add(login2);

        // ----------------------------------- MAIN PAGE
        search.setBounds(30, 30, 730, 30);

        mainPageFrame.add(mainPage, BorderLayout.CENTER);
        mainPageFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainPageFrame.setSize(800, 800);
        mainPageFrame.setTitle("Ana Sayfa");
        mainPageFrame.setResizable(false);
        mainPageFrame.setVisible(false);

        searchButton = new JButton("Ara");
        searchButton.setBounds(30, 100, 200, 50);
        searchButton.setFocusable(false);
        searchButton.addActionListener(e -> performSearch());
        searchButton.setEnabled(false);

        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                checkSearchField();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                checkSearchField();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                checkSearchField();
            }

            private void checkSearchField() {
                searchButton.setEnabled(!search.getText().trim().isEmpty());
            }
        });

        resultLabel.setBounds(10, 60, 1200, 50);

        chatButton = new JButton("Chat");
        chatButton.setBounds(350, 160, 100, 50);
        chatButton.setFocusable(false);
        chatButton.addActionListener(e -> changeFrame(mainPageFrame, chatFrame));


        mainPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        mainPage.setLayout(null);
        mainPage.add(search);
        mainPage.add(searchButton);
        mainPage.add(chatButton);
        mainPage.add(resultLabel);
        mainPage.add(reportButton);

        // ------------------------------------------ GRIP PAGE

        
        reportButtonGripPage = new JButton("Rapora geç");
        reportButtonGripPage.setBounds(580, 620, 180, 100);
        reportButtonGripPage.setFont(new Font("Arial", Font.BOLD, 23));
        reportButtonGripPage.setVisible(false);
        reportButtonGripPage.setFocusable(false);
        reportButtonGripPage.addActionListener(e -> changeFrame(gripFrame, reportFrame));

        gripFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gripFrame.setSize(800, 800);
        gripFrame.setTitle("Grip");
        gripFrame.setResizable(false);
        gripFrame.setVisible(false);

        gripLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));
        gripLabel.setBounds(100, 100, 400, 50);


        gripPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        gripPage.setLayout(null);
        gripPage.add(gripLabel);
        gripPage.add(reportButtonGripPage);

        gripFrame.add(gripPage, BorderLayout.CENTER);


        // ------------------------------------------ CHATBOT PAGE

        chatPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        chatPage.setLayout(null);


        chatFrame.add(chatPage, BorderLayout.CENTER);
        chatFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        chatFrame.setSize(800, 800);
        chatFrame.setTitle("Chatbot");
        chatFrame.setResizable(false);


        chatLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));
        chatLabel.setBounds(100, 100, 400, 50);

        chat.setBounds(50, 80, 700, 60);

        chatWork = new JButton("Ara");
        chatWork.addActionListener(e -> {
            String userMessage = chat.getText().trim();
            if (!userMessage.isEmpty()) {
                new SwingWorker<String, Void>() {
                    @Override
                    protected String doInBackground() throws Exception {
                        return ollamaService.sendMessage(userMessage);
                    }

                    @Override
                    protected void done() {
                        try {
                            chatDisplay.setText(get());
                        } catch (Exception ex) {
                            chatDisplay.setText("Hata oluştu: " + ex.getMessage());
                            ex.printStackTrace();
                        }
                    }
                }.execute();

            }
        });

        chatWork.setBounds(275, 160, 200, 60);
        chatWork.setFont(new Font("MV Boli", Font.PLAIN, 30));
        chatWork.setFocusable(false);

        chatDisplay.setEditable(false);
        chatDisplay.setLineWrap(true);
        chatDisplay.setWrapStyleWord(true);
        chatDisplay.setBounds(50, 230, 700, 400);

        backButton = new JButton("Geri");
        backButton.setBounds(500, 670, 200, 60);
        backButton.setFont(new Font("MV Boli", Font.PLAIN, 30));
        backButton.setFocusable(false);
        backButton.addActionListener(e -> changeFrame(chatFrame, mainPageFrame));


        chatPage.add(chatLabel);
        chatPage.add(chat);
        chatPage.add(chatDisplay);
        chatPage.add(chatWork);
        chatPage.add(backButton);

        // ----------------------------------------- CHOOSE FROM 3 PAGE

        introductionPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        introductionPage.setLayout(null);

        introductionLabel.setBounds(130, 60, 1200, 50);
        introductionLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));

        introductionFrame.add(introductionPage, BorderLayout.CENTER);
        introductionFrame.setVisible(false);
        introductionFrame.setResizable(false);
        introductionFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        introductionFrame.setSize(500, 500);
        introductionFrame.setTitle("Seçenekler");


        generalButton = new JButton("Bilgi ver");

        introButton = new JButton("Tanıt");

        proceedMain = new JButton("Devam et");


        generalButton.setBounds(50, 130, 180, 50);
        generalButton.setFocusable(false);
        generalButton.addActionListener(e -> changeFrame(introductionFrame, infoFrame));

        introButton.setBounds(250, 130, 180, 50);
        introButton.setFocusable(false);
        introButton.addActionListener(e -> changeFrame(introductionFrame, acquaintFrame));


        proceedMain.setBounds(150, 200, 180, 100);
        proceedMain.setFont(new Font("Arial", Font.BOLD, 23));
        proceedMain.setFocusable(false);
        proceedMain.addActionListener(e -> changeFrame(introductionFrame, mainPageFrame));


        introductionPage.add(introductionLabel);
        introductionPage.add(generalButton);
        introductionPage.add(introButton);
        introductionPage.add(proceedMain);

        // -------------------------------------- INFO PAGE

        infoPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        infoPage.setLayout(null);

        infoFrame.add(infoPage, BorderLayout.CENTER);
        infoFrame.setVisible(false);
        infoFrame.setResizable(false);
        infoFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        infoFrame.setSize(500, 500);
        infoFrame.setTitle("Bilgiler");

        backInfoButton = new JButton("Geri");
        backInfoButton.setBounds(160, 225, 100, 100);
        backInfoButton.setFont(new Font("Arial", Font.BOLD, 23));
        backInfoButton.setVisible(true);
        backInfoButton.setFocusable(false);
        backInfoButton.addActionListener(e -> changeFrame(infoFrame, introductionFrame));

        infoDisplay.setEditable(false);
        infoDisplay.setText("Uygulamanın nasıl çalıştığı hakkında küçük bir açıklama");
        infoDisplay.setBounds(25, 100, 300, 100);

        infoPage.add(infoDisplay);
        infoPage.add(backInfoButton);

        // -------------------------------------------- ACQUAINT PAGE

        acquaintPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        acquaintPage.setLayout(null);

        acquaintFrame.add(acquaintPage, BorderLayout.CENTER);
        acquaintFrame.setVisible(false);
        acquaintFrame.setResizable(false);
        acquaintFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        acquaintFrame.setSize(500, 500);
        acquaintFrame.setTitle("Tanıtım");

        backAcquaintButton = new JButton("Geri");
        backAcquaintButton.setBounds(160, 225, 100, 100);
        backAcquaintButton.setFont(new Font("Arial", Font.BOLD, 23));
        backAcquaintButton.setVisible(true);
        backAcquaintButton.setFocusable(false);
        backAcquaintButton.addActionListener(e -> changeFrame(acquaintFrame, introductionFrame));

        acquaintPage.add(backAcquaintButton);

        // --------------------------------------------- INFO COLLECTOR PAGE

        collectorPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        collectorPage.setLayout(null);

        collectorFrame.add(collectorPage, BorderLayout.CENTER);
        collectorFrame.setVisible(false);
        collectorFrame.setResizable(false);
        collectorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        collectorFrame.setSize(500, 500);
        collectorFrame.setTitle("Önemli Bilgiler");

        genderLabel.setBounds(40, 20, 180, 100);
        genderLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));

        ageLabel.setBounds(40, 100, 180, 100);
        ageLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));

        symptomsLabel.setBounds(40, 180, 180, 100);
        symptomsLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));

        genderSlider.setMajorTickSpacing(1);
        genderSlider.setPaintTicks(true);
        genderSlider.setPaintLabels(true);
        Hashtable<Integer, JLabel> labelTable = new Hashtable<>();
        labelTable.put(0, new JLabel("Erkek"));
        labelTable.put(1, new JLabel("Kız"));
        genderSlider.setLabelTable(labelTable);
        genderSlider.setBounds(175, 40, 300, 60);

        genderDisplayLabel.setBounds(275, 75, 100, 30);
        genderDisplayLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));
        selectedGender = "Erkek";
        genderSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int value = genderSlider.getValue();
                if (value == 0) {
                    selectedGender = "Erkek";
                } else {
                    selectedGender = "Kız";
                }
                genderDisplayLabel.setText(selectedGender);
            }
        });


        collectorButton = new JButton("Bitir");
        collectorButton.setBounds(150, 320, 180, 100);
        collectorButton.setFont(new Font("Arial", Font.BOLD, 23));
        collectorButton.setFocusable(false);
        collectorButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String gender = selectedGender;
                String ageText = ageField.getText().trim();
                String symptoms = symptomsField.getText().trim();

                if (gender.isEmpty() || ageText.isEmpty() || symptoms.isEmpty()) {
                    JOptionPane.showMessageDialog(collectorFrame, "Lütfen tüm alanları doldurun.", "Eksik Bilgi", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                try {
                    int age = Integer.parseInt(ageText);
                    userData = new UserData(gender, age, symptoms);
                    changeFrame(collectorFrame, introductionFrame);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(collectorFrame, "Lütfen geçerli bir yaş giriniz.", "Hatalı Giriş", JOptionPane.ERROR_MESSAGE);
                }
            }


        });

        ageField.setBounds(175, 120, 300, 60);
        symptomsField.setBounds(175, 200, 300, 60);


        collectorPage.add(genderLabel);
        collectorPage.add(ageLabel);
        collectorPage.add(symptomsLabel);
        collectorPage.add(ageField);
        collectorPage.add(symptomsField);
        collectorPage.add(collectorButton);
        collectorPage.add(genderSlider);

        // -------------------------------------------------------------------- REPORT PAGE

        reportPage.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        reportPage.setLayout(null);

        reportFrame.add(reportPage, BorderLayout.CENTER);
        reportFrame.setVisible(false);
        reportFrame.setResizable(false);
        reportFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        reportFrame.setSize(800, 800);
        reportFrame.setTitle("Rapor");

        reportLabel.setBounds(40, 180, 180, 100);
        reportLabel.setFont(new Font("MV Boli", Font.PLAIN, 30));

        genderReportLabel = new JLabel();
        genderReportLabel.setBounds(40, 50, 300, 30);
        genderReportLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));

        ageReportLabel = new JLabel();
        ageReportLabel.setBounds(40, 90, 300, 30);
        ageReportLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));

        symptomsReportLabel = new JLabel();
        symptomsReportLabel.setBounds(40, 130, 700, 30);
        symptomsReportLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));

        sypmtomsLabel.setBounds(300, 50, 700, 30);
        sypmtomsLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));

        sicknessLabel.setBounds(300, 90, 700, 30);
        sicknessLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));

        adviceLabel.setBounds(300, 130, 700, 30);
        adviceLabel.setFont(new Font("MV Boli", Font.PLAIN, 20));


        reportPage.add(genderReportLabel);
        reportPage.add(ageReportLabel);
        reportPage.add(symptomsReportLabel);
        reportPage.add(reportLabel);
        reportPage.add(closeButton);
        reportPage.add(sypmtomsLabel);
        reportPage.add(sicknessLabel);
        reportPage.add(adviceLabel);

        // -----------------------------------------------------------------------


        //URL resim koyma


        try {

            URL imageUrl = URI.create("file:///C:/Users/dell/Downloads/images%20(3).jpg").toURL();
            Image resized1 = new ImageIcon(imageUrl).getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(resized1);
            JLabel docPic = new JLabel(icon);
            docPic.setBounds(30, 300, 730, 500);

            URL imageUrl2 = URI.create("file:///C:/Users/dell/Downloads/images%20(2).jpg").toURL();
            ImageIcon icon2 = new ImageIcon(imageUrl2);
            JLabel patient = new JLabel(icon2);
            patient.setBounds(30, 100, 730, 500);

            mainPage.add(docPic);
            mainPage.add(patient);

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("GUI Initialized.");
    }

    // main page'deki araştırma komutu
    void performSearch() {
        String userInput = search.getText().trim();
        List<Disease> results = diseaseService.predictDisease(userInput);

        if (results.isEmpty()) {
            resultLabel.setText("Uygun hastalık bulunamadı.");
            lastPredictedDisease = null;
            return;
        }

        lastPredictedDisease = results.get(0);

        StringBuilder resultText = new StringBuilder("Tahmin edilen hastalık: ");
        for (Disease d : results) {
            resultText.append(d.getName());
        }
        resultLabel.setText(resultText.toString());

        for (Disease d : results) {
            if (d.getName().equalsIgnoreCase("Grip")) {
                reportButtonGripPage.setVisible(true);
                mainPageFrame.setVisible(false);
                gripFrame.setVisible(true);
                return;
            }
            reportButton.setVisible(true); 
        }
    }

    // Son raporu günceller
    void updateReportLabels() {
        if (userData != null) { 
            genderReportLabel.setText("Cinsiyet: " + userData.getGender()); 
            ageReportLabel.setText("Yas: " + userData.getAge()); 
            symptomsReportLabel.setText("Açıklama: " + userData.getSymptoms()); 
        }
        if (lastPredictedDisease != null) {
            sypmtomsLabel.setText("Belirtiler: " + lastPredictedDisease.getSymptomsAsString()); 
            sicknessLabel.setText("Hastalık: " + lastPredictedDisease.getName()); 
            adviceLabel.setText("Tavsiye: " + lastPredictedDisease.getTreatment()); 
        }
    }


    void changeFrame(JFrame oldFrame, JFrame newFrame) {
        oldFrame.setVisible(false);
        updateReportLabels();
        newFrame.setVisible(true);
    }

    void loggingIn() {
        String username = login1.getText();
        char[] passwordChars = login2.getPassword();
        String password = new String(passwordChars);

        if (username.equals("1") && password.equals("2")) {
            frame.setVisible(false);
            collectorFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(frame, "Yanlış şifre", "Hata", JOptionPane.WARNING_MESSAGE);
        }
        Arrays.fill(passwordChars, ' '); //şifreyi sıfırlar
    }

}